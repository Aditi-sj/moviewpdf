package com.shalem.catalougeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalougeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
