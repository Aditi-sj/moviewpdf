package com.shalem.catalougeservice.controller;

import com.shalem.catalougeservice.common.TransactionRequest;
import com.shalem.catalougeservice.common.TransactionResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/catalouge")
public class CatalougeController {
    @Autowired
    private RestTemplate restTemplate;

    @PostMapping("/order")
    public TransactionResponse callToOrderService(@RequestBody TransactionRequest transactionRequest){
        TransactionResponse response=restTemplate.postForObject("http://ORDER-SERVICE/order/placeOrder",transactionRequest,TransactionResponse.class);
        return response;
    }
}
