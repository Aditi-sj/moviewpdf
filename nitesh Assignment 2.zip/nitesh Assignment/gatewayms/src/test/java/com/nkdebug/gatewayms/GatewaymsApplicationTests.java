package com.nkdebug.gatewayms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewaymsApplicationTests {

	@Test
	void contextLoads() {
	}

}
