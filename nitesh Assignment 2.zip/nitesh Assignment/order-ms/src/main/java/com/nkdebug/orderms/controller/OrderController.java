package com.nkdebug.orderms.controller;


import com.nkdebug.orderms.common.Payment;
import com.nkdebug.orderms.common.TransactionRequest;
import com.nkdebug.orderms.common.TransactionResponse;
import com.nkdebug.orderms.entity.Order;
import com.nkdebug.orderms.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/order")
public class OrderController {

  @Autowired
  private OrderService orderService;

  @PostMapping("/placeOrder")
  public TransactionResponse placeOrder(@RequestBody TransactionRequest request) {

    return orderService.placeOrder(request);

    // call payment ms and pass order id
  }
}
