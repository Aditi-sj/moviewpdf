package com.nkdebug.orderms.service;

import com.nkdebug.orderms.common.Payment;
import com.nkdebug.orderms.common.TransactionRequest;
import com.nkdebug.orderms.common.TransactionResponse;
import com.nkdebug.orderms.entity.Order;
import com.nkdebug.orderms.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.mongo.ReactiveStreamsMongoClientDependsOnBeanFactoryPostProcessor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class OrderService {


    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private RestTemplate restTemplate;

    public TransactionResponse placeOrder(TransactionRequest request) {

      String response = "";
      Order order = request.getOrder();
      Payment payment = request.getPayment();
      payment.setOrderId(order.getId());
      payment.setAmount(order.getPrice());

      // API CALL TO PAYMENT SERVICE
      Payment paymentResp = restTemplate.postForObject("http://PAYMENT-SERVICE/payment/doPayment", payment, Payment.class);

      if(paymentResp.getPaymentStatus().equals("success")) {
        response = "payment processing is successfully & order is placed";
      } else {
        response = "There is failure in payment api, retry again";
      }

      orderRepository.save(order);
      TransactionResponse transactionResponse = new TransactionResponse(order, payment.getAmount(), paymentResp.getTransactionId(), response);
      return transactionResponse;
    }

}
