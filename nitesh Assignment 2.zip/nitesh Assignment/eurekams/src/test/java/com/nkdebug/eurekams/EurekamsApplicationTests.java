package com.nkdebug.eurekams;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekamsApplicationTests {

	@Test
	void contextLoads() {
	}

}
