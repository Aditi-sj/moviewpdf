package com.nkdebug.payment.service;

import com.nkdebug.payment.entity.Payment;
import com.nkdebug.payment.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Random;
import java.util.UUID;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;


    public Payment doPayment(Payment payment) {
        payment.setPaymentStatus(paymentProcessing());
        payment.setTransactionId(UUID.randomUUID().toString());
        return paymentRepository.save(payment);
    }

    public Payment findOrder(int orderId) {

        return paymentRepository.findByOrderId(orderId);
    }


    public String paymentProcessing() {
        // call to payment gateway --> paytm or razorpay
        return new Random().nextBoolean()?"success": "failure";
    }


}
